import java.util.Scanner;

public class FibonacciSerisi {

    static void FibonacciSeri(int N)
    {
        int num1 = 0, num2 = 1;
        int i;
        for(i=0;i<N;i++){
            System.out.print(num1 + " ");
            int num3=num1+num2;
            num1=num2;
            num2=num3;

        }
    }

    // Driver Code
    public static void main(String args[])
    {
        Scanner input=new Scanner(System.in);
        System.out.println(" inter  a number of Fibonacci seri :  ");

        int N;
        N=input.nextInt();


        FibonacciSeri(N);
    }
}


